﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsTools
{
    public partial class Form2 : Form
    {
        public Form2(string checkdedItems)
        {
            InitializeComponent();
            checkedValues.Text = checkdedItems;
        }

        private void Close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void updateCheckedValues(string value)
        {
            checkedValues.Text = value;
        }
    }
}
