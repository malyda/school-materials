﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        // Variable for new button in Form is accessed from newButtonInRuntime and button2_Click methods
        Button button2;

        /// <summary>
        /// Constructor for application logic of Form1
        /// </summary>
        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// onClick event handler for button declared in Form1.Designer
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            // Application logic after click on button
            
            // get value from textBox1 a show it in MessageBox
            string value = textBox1.Text;
            if (String.IsNullOrEmpty(value)) value = "Your text box is empty";
            MessageBox.Show(value);

            //Create new button in Form1 and connect eventHandler method for onClick event
            newButtonInRuntime();
        }

        /// <summary>
        /// onTextChangedHandler caller every time, when is value of attribute Text in textBox1 object changed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           // You can handle every onTextChanged event if you want
        }

        /// <summary>
        /// Adds new button to this Form in Runtime
        /// Do not checks if is there some other, so it will add new button every time
        /// </summary>
        private void newButtonInRuntime()
        {
            
            button2 = new Button(); // Create new intance of class Button

            // Set some default attributes
            button2.Size = new Size(40, 40);
            button2.Location = new Point(30, 30);
            button2.Text = "Click me";

            // Connect new Button to onClick event handler
            button2.Click += new EventHandler(button2_Click);
        
            // Add new button to Form1 so now it is visible
            this.Controls.Add(button2);
          
        }

        /// <summary>
        /// onClick event handler for button declared and added in runtime
        /// Connect new button with onClick method handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button2_Click(object sender, EventArgs e)
        {
            // Set new location for first button
            button2.Location = new Point(60, 60);

            // shows "This window is called from your new Button"
            MessageBox.Show("This window is called from your new Button");
        }
    }
}
