﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// Implements INotifyPropertyChanged interface used for notifing UI about changes
    /// </summary>
    /// 
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        /// <summary>
        /// Private field
        /// </summary>
        private int ValueInXml;

        /// <summary>
        /// Event handler 
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// Public property used in label
        /// </summary>
        public int valueInXml
        {
            get
            {
                return ValueInXml;
            }
            set
            {
                ValueInXml = value;

                // Notify about change and specific which property changed
                OnPropertyChanged("valueInXml");
            }
        }
        /// <summary>
        /// Notify about property changes
        /// </summary>
        /// <param name="name"></param>
        protected void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }
        /// <summary>
        /// Constructor implements onLoaded listener
        /// </summary>
        public MainWindow()
        {
            DataContext = this;
            InitializeComponent();
            Loaded += onLoaded;


            Guys = new ObservableCollection<Person>();
            Guys.Add(new Person("Julius Caesar", 40));
            Guys.Add(new Person("Pompeius Magnus", 46));
            Guys.Add(new Person("Marcus Crassus", 55));


            RaisePropertyChanged("Guys");
        }

        public ObservableCollection<Person> Guys { get; protected set; }
        private void RaisePropertyChanged(string propName)
        {
            PropertyChanged(this, new PropertyChangedEventArgs(propName));
        }
        /// <summary>
        /// Implementation of window loaded listener
        /// Starts neverending cycle which increment binded variable
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void onLoaded(Object sender, RoutedEventArgs e)
        {
            Task task = new Task(new Action(threadMethod));
            task.Start();
        }

        /// <summary>
        /// Thread method
        /// </summary>
        private void threadMethod()
        {
            while(true)
            {
                valueInXml++;
            }  
        }
    }
}
