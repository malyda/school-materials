﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TaskApp
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // Tasks();
            // Threads();
            // ThreadPools();
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }


        public static void Tasks()
        {
            var instance = new Taask.Taask();

            CancellationTokenSource cts = new CancellationTokenSource();
            // Vysvětlit dataObject
            DataStore data = new DataStore();
            Debug.WriteLine("before task " + data.Cislo);

            instance.StartNeverEndingProc(cts.Token, data);
            Thread.Sleep(1000);

            Debug.WriteLine("after task" + data.Cislo);

            cts.Cancel();
        }

         public static void Threads()
        {
            var instance = new Threads.Threads();

            CancellationTokenSource cts = new CancellationTokenSource();

            DataStore data = new DataStore();
            Debug.WriteLine("before thread " + data.Cislo);

            instance.StartNeverEndingProc(cts.Token, data);

            Thread.Sleep(1000);

            Debug.WriteLine("after thread" + data.Cislo);

            cts.Cancel();
        }

        public static void ThreadPools()
        {
            var instance = new ThreadPools.ThreadPools();

            CancellationTokenSource cts = new CancellationTokenSource();

            DataStore data = new DataStore();
            Debug.WriteLine("before thread " + data.Cislo);

            instance.StartNeverEndingProc(cts.Token, data);

            Thread.Sleep(1000);

            Debug.WriteLine("after thread" + data.Cislo);

            cts.Cancel();
        }
    }
}
