﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TaskApp.SimpleThread
{
    class SimpleThread
    {
        public void StartNeverEndingProc()
        {
            Console.WriteLine(Thread.CurrentThread.Name);


            Thread workerThread = new Thread(NeverEndingProc);
            workerThread.Name = "workerThread";
            workerThread.Priority = ThreadPriority.Normal;
            workerThread.IsBackground = true;

            workerThread.Start();
            
        }


        private void NeverEndingProc()
        {
            Console.WriteLine(Thread.CurrentThread.Name);
            int i = 0;
            while (true)
            {
                i++;
            }
        }
    }
}
