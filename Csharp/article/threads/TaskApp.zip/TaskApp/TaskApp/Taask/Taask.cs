﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TaskApp.Taask
{
    class Taask
    {
        DataStore dataStore;
        public void StartNeverEndingProc(CancellationToken token, DataStore data)
        {
            dataStore = data;
            Task.Factory.StartNew(() => NeverEndingProc(token));
        }


        private void NeverEndingProc(CancellationToken token)
        {
            int i = 0;
            while (true)
            {
                if (token.IsCancellationRequested) return;
                Debug.WriteLine(i);
                i++;
                dataStore.Cislo = i;
             }
        }
    }
}
