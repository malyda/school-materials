﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TaskApp.SimpleTask
{
    class SimpleTask
    {
        public void StartNeverEndingProc(CancellationToken token)
        {
            Task task = new Task(new Action(NeverEndingProc));
            task.Start();
        }


        private void NeverEndingProc()
        {
            int i = 0;
            while (true)
            {
                i++;
            }
        }
    }
}
