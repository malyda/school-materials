﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskApp
{
    class DataStore
    {
        private volatile int cislo;
        private object locker = new object();
        public int Cislo
        {
           
            get
            {
                int result;
                lock (locker)
                {
                    result = cislo;
                }
                return result;
            }
         
            set
            {
              
                lock(locker) cislo = value;
            }
            // Čtení a zároveň zápis do jedné proměnné je nebezpečné
            // Proto je použit vždy stejný zámek
        }
    }
}
