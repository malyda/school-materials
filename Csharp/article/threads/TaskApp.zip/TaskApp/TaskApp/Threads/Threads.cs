﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TaskApp.Threads
{
    class Threads
    {
        DataStore dataStore;
        public void StartNeverEndingProc(CancellationToken token, DataStore data)
        {
            dataStore = data;
            Thread myNewThread = new Thread(() => NeverEndingProc(token) );
            myNewThread.Start();
        }


        private void NeverEndingProc(CancellationToken token)
        {
            int i = 0;
            while (true)
            {
                //token.ThrowIfCancellationRequested();
                if (token.IsCancellationRequested) return;
                Debug.WriteLine(i);
                i++;
                dataStore.Cislo = i;
            }
        }
    }
}
