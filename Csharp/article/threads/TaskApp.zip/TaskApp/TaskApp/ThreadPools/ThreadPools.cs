﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;

namespace TaskApp.ThreadPools
{
    class ThreadPools
    {
        DataStore dataStore;
        public void StartNeverEndingProc(CancellationToken token, DataStore data)
        {
            dataStore = data;      
            ThreadPool.QueueUserWorkItem(new WaitCallback(NeverEndingProc), token); 
        }

        private void NeverEndingProc(Object token)
        {
            int i = 0;
            while (true)
            {
                //token.ThrowIfCancellationRequested();
                if ( ( (CancellationToken) token).IsCancellationRequested) return;
                Debug.WriteLine(i);
                i++;
                dataStore.Cislo = i;
            }
        }
    }
}
