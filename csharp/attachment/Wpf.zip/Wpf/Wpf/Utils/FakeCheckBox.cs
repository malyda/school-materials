﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wpf
{
  public class FakeCheckBox
    {
        public string TheText { get; set; }
        public bool IsSelected { get; set; }
    }
}
