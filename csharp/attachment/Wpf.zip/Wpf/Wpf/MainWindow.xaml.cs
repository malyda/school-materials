﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Wpf
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //resource for checkboxes via DataBinding
        public ObservableCollection<FakeCheckBox> CheckBoxList{ get; set; }
        // Handler for second Window
        Window2 window2;

        public MainWindow()
        {
            InitializeComponent();
            CheckBoxList = new ObservableCollection<FakeCheckBox>();

            // Create CheckBoxList
            CheckBoxList.Add(new FakeCheckBox { IsSelected = false, TheText = "first" });
            CheckBoxList.Add(new FakeCheckBox { IsSelected = false, TheText = "second" });
            CheckBoxList.Add(new FakeCheckBox { IsSelected = false, TheText = "third" });

            this.DataContext = this;
        }
        ///
        public void removeButtonClick(Object sender, EventArgs e)
        {
            if (listView.Items.Count > 0)
            {
                listView.Items.RemoveAt(0);
                eventBox.Text = "item removed";
            }

            
        }

        public void addButtonClick(Object sender, EventArgs e)
        {
            listView.Items.Add("programaticky přidaná položka");
            eventBox.Text  =  "item added";
        }

        private void CheckBoxListAddButton_Click(object sender, RoutedEventArgs e)
        {
            CheckBoxList.Add(new FakeCheckBox { IsSelected = false, TheText = "new item in runtime" });
            eventBox.Text = "checkBox added";
        }

        private void CheckBoxListRemoveButton_Click(object sender, RoutedEventArgs e)
        {
            if (CheckBoxList.Count > 0)
            {
                CheckBoxList.RemoveAt(0);
                eventBox.Text = "checkBox removed";
            }
        }
        /// <summary>
        /// Event listener for Checking checkboxes
        /// Show changed checkbox in EventBox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void CheckBoxChanged(Object sender, EventArgs e)
        { 
            eventBox.Text = (String)(  ((CheckBox)sender).Content ) ;
        }

        /// <summary>
        /// Show new window if is not open or
        /// Update opened window
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void NewWindow_Click(object sender, RoutedEventArgs e)
        {
            // Data to pass
            StringBuilder builder = new StringBuilder();

            // Collect all checked checkboxes
            foreach(FakeCheckBox one in CheckBoxList)
            {
                if (one.IsSelected) builder.Append(one.TheText + " ");
            }
            if (builder.Length == 0) builder.Append("No checked values");

            // Checks if is Window2 opened
            if (Utils.WindowHelper.IsWindowOpen<Window>("Window1")) window2.Update(builder.ToString());
            else
            {
                window2 = new Window2(builder.ToString());
                window2.Show();
            }
               
        }


    }
}
