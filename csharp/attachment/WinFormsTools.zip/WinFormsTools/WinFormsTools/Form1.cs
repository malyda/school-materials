﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace WinFormsTools
{
    public partial class Form1 : Form
    {
        List<string> checkedItems;
        public Form1()
        {
            InitializeComponent();
         
        }
        /// <summary>
        /// Zobrazuje zaškrtnutá políčka
        /// Pořadí není garantované
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void checkedListBox1_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            checkedItems = new List<string>();
            foreach (var item in checkedListBox1.CheckedItems)  checkedItems.Add(item.ToString());

            if (e.NewValue == CheckState.Checked) checkedItems.Add(checkedListBox1.Items[e.Index].ToString());
            else checkedItems.Remove(checkedListBox1.Items[e.Index].ToString());      

            EventBox.Text = "";
            foreach (string item in checkedItems) EventBox.Text += item+" ";
        }

        /// <summary>
        /// Přidá položku do ListView
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AddToListView_Click(object sender, EventArgs e)
        {
            listView2.Items.Add("List item text");
            EventBox.Text = "ListView item added";
        }

        /// <summary>
        /// Přidá položku do ListBoxu po kliknutí na tlačítko
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AddToListBox_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add("Programaticky přidaná položka");
            EventBox.Text = "ListBox item added";
        }

        /// <summary>
        /// Odebere položku z ListView po kliknutí na tlačítko
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DeleteFromListView_Click(object sender, EventArgs e)
        {
            if (listView2.Items.Count > 0)
            {
                listView2.Items.RemoveAt(0);
                EventBox.Text = "ListView item removed";
            }
           else EventBox.Text = "ListView is empty";
        }

        /// <summary>
        /// Odebere položku z ListBoxu po kliknutí na tlačítko
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DeleteFromListBox_Click(object sender, EventArgs e)
        {
            if (listBox1.Items.Count > 0)
            {
                listBox1.Items.RemoveAt(0);
                EventBox.Text = "ListBox item removed";
            }
            else EventBox.Text = "ListBox is empty";
        }

        private void newForm_Click(object sender, EventArgs e)
        {
            Form2 form = new Form2();
            if(checkedItems != null) foreach (string item in checkedItems) form.checkedValues.Text += item + " ";
            form.Show();
        }
    }
}
