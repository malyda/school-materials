﻿using System.Drawing;

namespace WinFormsTools
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.ListViewItem listViewItem4 = new System.Windows.Forms.ListViewItem("Položka 1");
            System.Windows.Forms.ListViewItem listViewItem5 = new System.Windows.Forms.ListViewItem("Položka 2");
            System.Windows.Forms.ListViewItem listViewItem6 = new System.Windows.Forms.ListViewItem("Položka 3");
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.listView2 = new System.Windows.Forms.ListView();
            this.AddToListView = new System.Windows.Forms.Button();
            this.AddToListBox = new System.Windows.Forms.Button();
            this.EventBox = new System.Windows.Forms.TextBox();
            this.DeleteFromListView = new System.Windows.Forms.Button();
            this.DeleteFromListBox = new System.Windows.Forms.Button();
            this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
            this.button2 = new System.Windows.Forms.Button();
            this.newForm = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Items.AddRange(new object[] {
            "Položka 1",
            "Položka 2",
            "Položka 3",
            "Položka 4",
            "Položka 5"});
            this.listBox1.Location = new System.Drawing.Point(497, 28);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(105, 95);
            this.listBox1.TabIndex = 0;
            // 
            // listView2
            // 
            this.listView2.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem4,
            listViewItem5,
            listViewItem6});
            this.listView2.Location = new System.Drawing.Point(40, 63);
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(163, 46);
            this.listView2.TabIndex = 1;
            this.listView2.UseCompatibleStateImageBehavior = false;
            // 
            // AddToListView
            // 
            this.AddToListView.Location = new System.Drawing.Point(83, 141);
            this.AddToListView.Name = "AddToListView";
            this.AddToListView.Size = new System.Drawing.Size(75, 23);
            this.AddToListView.TabIndex = 2;
            this.AddToListView.Text = "Add";
            this.AddToListView.UseVisualStyleBackColor = true;
            this.AddToListView.Click += new System.EventHandler(this.AddToListView_Click);
            // 
            // AddToListBox
            // 
            this.AddToListBox.Location = new System.Drawing.Point(509, 141);
            this.AddToListBox.Name = "AddToListBox";
            this.AddToListBox.Size = new System.Drawing.Size(75, 23);
            this.AddToListBox.TabIndex = 3;
            this.AddToListBox.Text = "Add";
            this.AddToListBox.UseVisualStyleBackColor = true;
            this.AddToListBox.Click += new System.EventHandler(this.AddToListBox_Click);
            // 
            // EventBox
            // 
            this.EventBox.Location = new System.Drawing.Point(244, 28);
            this.EventBox.Name = "EventBox";
            this.EventBox.Size = new System.Drawing.Size(154, 20);
            this.EventBox.TabIndex = 4;
            this.EventBox.Text = "EventBox";
            this.EventBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // DeleteFromListView
            // 
            this.DeleteFromListView.Location = new System.Drawing.Point(83, 170);
            this.DeleteFromListView.Name = "DeleteFromListView";
            this.DeleteFromListView.Size = new System.Drawing.Size(75, 23);
            this.DeleteFromListView.TabIndex = 5;
            this.DeleteFromListView.Text = "Delete";
            this.DeleteFromListView.UseVisualStyleBackColor = true;
            this.DeleteFromListView.Click += new System.EventHandler(this.DeleteFromListView_Click);
            // 
            // DeleteFromListBox
            // 
            this.DeleteFromListBox.Location = new System.Drawing.Point(509, 170);
            this.DeleteFromListBox.Name = "DeleteFromListBox";
            this.DeleteFromListBox.Size = new System.Drawing.Size(75, 23);
            this.DeleteFromListBox.TabIndex = 6;
            this.DeleteFromListBox.Text = "Delete";
            this.DeleteFromListBox.UseVisualStyleBackColor = true;
            this.DeleteFromListBox.Click += new System.EventHandler(this.DeleteFromListBox_Click);
            // 
            // checkedListBox1
            // 
            this.checkedListBox1.CheckOnClick = true;
            this.checkedListBox1.FormattingEnabled = true;
            this.checkedListBox1.Items.AddRange(new object[] {
            "first",
            "second",
            "third",
            "fourth",
            "fifth"});
            this.checkedListBox1.Location = new System.Drawing.Point(267, 70);
            this.checkedListBox1.Name = "checkedListBox1";
            this.checkedListBox1.Size = new System.Drawing.Size(120, 94);
            this.checkedListBox1.TabIndex = 8;
            this.checkedListBox1.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.checkedListBox1_ItemCheck);
            // 
            // button2
            // 
            this.button2.Image = global::WinFormsTools.Properties.Resources.Icon;
            this.button2.Location = new System.Drawing.Point(191, 224);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(292, 207);
            this.button2.TabIndex = 9;
            this.button2.UseVisualStyleBackColor = true;
            // 
            // newForm
            // 
            this.newForm.Location = new System.Drawing.Point(285, 170);
            this.newForm.Name = "newForm";
            this.newForm.Size = new System.Drawing.Size(75, 23);
            this.newForm.TabIndex = 10;
            this.newForm.Text = "New Form";
            this.newForm.UseVisualStyleBackColor = true;
            this.newForm.Click += new System.EventHandler(this.newForm_Click);
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(668, 443);
            this.Controls.Add(this.newForm);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.checkedListBox1);
            this.Controls.Add(this.DeleteFromListBox);
            this.Controls.Add(this.DeleteFromListView);
            this.Controls.Add(this.EventBox);
            this.Controls.Add(this.AddToListBox);
            this.Controls.Add(this.AddToListView);
            this.Controls.Add(this.listView2);
            this.Controls.Add(this.listBox1);
            this.Name = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.Button AddToListView;
        private System.Windows.Forms.Button AddToListBox;
        private System.Windows.Forms.TextBox EventBox;
        private System.Windows.Forms.Button DeleteFromListView;
        private System.Windows.Forms.Button DeleteFromListBox;
        private System.Windows.Forms.CheckedListBox checkedListBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button newForm;
    }
}

