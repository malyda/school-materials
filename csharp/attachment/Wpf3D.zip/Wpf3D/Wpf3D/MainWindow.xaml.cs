﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Wpf3D
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        AxisAngleRotation3D ax3d;
        AxisAngleRotation3D ax3d2;
        public MainWindow()
        {
            InitializeComponent();
            ax3d = new AxisAngleRotation3D(new Vector3D(0, 0, 2), 1);
            RotateTransform3D myRotateTransform = new RotateTransform3D(ax3d);


            ax3d2 = new AxisAngleRotation3D(new Vector3D(0, 2, 0), 1);
            RotateTransform3D myRotateTransform2 = new RotateTransform3D(ax3d2);


            Transform3DGroup transforms = new Transform3DGroup();

            transforms.Children.Add(myRotateTransform);
            transforms.Children.Add(myRotateTransform2);

            Model.Transform = transforms;
        }

        public void MySlider_X(Object sender, EventArgs e)
        {
            ax3d.Angle = slider.Value;
        }

        public void MySlider_Y(Object sender, EventArgs e)
        {
            ax3d2.Angle = slider_Copy.Value;   
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            Window1 w1 = new Window1();
            w1.Show();
        }
    }
}
