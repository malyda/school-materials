﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsEvents
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            registrateEvents();
        }

        private void registrateEvents()
        {
            HandleCreated += button2_HandleCreated;
            button2.BindingContextChanged += new EventHandler(BindingContext_Changed);
   
            this.Load += new System.EventHandler(this.Form1_Load);
            this.VisibleChanged += new System.EventHandler(this.Form1_VisibleChanged);
            this.Activated += new System.EventHandler(this.Form1_Activated);
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            // Manuální zaregistrování naslouchání události
            Debug.WriteLine("Celý form připraven ke zobrazení");
        }


        private void Form1_VisibleChanged(object sender, EventArgs e)
        {
            // Manuální zaregistrování naslouchání události
            Debug.WriteLine("Změnila se viditelnost formuláře");
        }

        private void Form1_Activated(object sender, EventArgs e)
        {
            // Manuální zaregistrování naslouchání události
            Debug.WriteLine("Formulář získal focus");
        }
        /// <summary>
        /// Událost zavolána po zobrazení tlačítka
        /// Je manuálně zaregistrovaná v konstruktoru třídy
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button2_HandleCreated(Object sender, EventArgs e)
        {
            Debug.WriteLine("Tlačítko je zobrazeno ve formuláři");
            button2.Location = new Point(30, 30);

        }

        /// <summary>
        /// Manuálně zaregistrované událost zavolaná po změně atributu button2
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BindingContext_Changed(object sender, EventArgs e)
        {
            Console.WriteLine("BindingContext changed");
        }

        /// <summary>
        /// Automaticky generovaná metoda
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button2_Click(object sender, EventArgs e)
        {
            Debug.WriteLine("Tlačítko je stisknuto");
        }
    }
}
